//package com.Real_Time_Event_Ticketing_System.backend;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class BackendApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
